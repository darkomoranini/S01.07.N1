package Ejercicio1;
	
@ClassPreamble (
		nombre = "Darko",
		apellido = "Morandini",
		descripcion = "Clase main"						
		)

public class UsoTrabajador {

	public static void main(String[] args) {
		
		TrabajadorPresencial trabajador1 = new TrabajadorPresencial("Darko", "Morandini", 28);
		System.out.println(trabajador1.calculaSueldo(160));
		
		TrabajadorOnline trabajador2 = new TrabajadorOnline("Ivan", "Alarcon", 25);
		System.out.println(	trabajador2.calculaSueldo(158));
	}

}
