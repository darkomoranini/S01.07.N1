package Ejercicio1;
	
@ClassPreamble (
		nombre = "Darko",
		apellido = "Morandini",
		descripcion = "Clase que recibe de Trabajador, añade una constante y sobre escribe el metodo que recibe de la clase madre"					
		)

public class TrabajadorOnline extends Trabajador{
	
	final int tarifaInternet;
	
	public TrabajadorOnline(String nombre, String apellido, int precioHora) {
		super(nombre, apellido, precioHora);
		tarifaInternet=50;
	}
	@Override
	public int calculaSueldo(int horasTrabajadasMes) {
		
		return super.calculaSueldo(horasTrabajadasMes)+tarifaInternet;
	}
	
	
}
