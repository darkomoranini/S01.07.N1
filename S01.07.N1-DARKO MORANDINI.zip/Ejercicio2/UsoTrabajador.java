package Ejercicio2;

@ClassPreamble (
		nombre = "Darko",
		apellido = "Morandini",
		descripcion = "Clase main"						
		)

public class UsoTrabajador {

	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		
		TrabajadorPresencial trabajador1 = new TrabajadorPresencial("Andrea", "Herrera", 29);
		System.out.println(trabajador1.calculaSueldo(160));
		
		TrabajadorOnline trabajador2 = new TrabajadorOnline("Ivan", "Alarcon", 25);
		System.out.println(	trabajador2.calculaSueldo(158));
	
		trabajador1.subirSueldo();
		
		trabajador2.calculaSueldoDia(20);
		
		
	}

}