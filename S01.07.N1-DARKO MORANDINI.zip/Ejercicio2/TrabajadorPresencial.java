package Ejercicio2;

@ClassPreamble (
		nombre = "Darko",
		apellido = "Morandini",
		descripcion = "Clase que recibe de Trabajador, añade un atributo static y sobre escribe el metodo que recibe de la clase madre"				
		)

public class TrabajadorPresencial extends Trabajador{

	static int benzina = 100;
	
	public TrabajadorPresencial(String nombre, String apellido, int precioHora) {
		super(nombre, apellido, precioHora);	
	}
	
	@Override
	public int calculaSueldo(int horasTrabajadasMes) {
		
		return super.calculaSueldo(horasTrabajadasMes)+benzina;
	}
	/**
	 * 
	 * @Deprecated
	 * Este metodo sube el sueldo doblando la variable static benzina
	 */
	@Deprecated
	public int subirSueldo() {
		return benzina*2;
	}

}